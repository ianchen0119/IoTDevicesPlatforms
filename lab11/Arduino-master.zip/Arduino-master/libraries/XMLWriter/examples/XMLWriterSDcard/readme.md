# XMLWriter 

### SDCARD demo notes

Do not forget the **XML.flush();**  before closing the FILE object.

