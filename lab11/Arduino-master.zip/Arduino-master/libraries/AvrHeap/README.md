# AVRheap
Arduino library to investigate the heap of an avr processor, e.g. UNO (AVR328).

Note: this is an experimental library, not for beginners.

## Description
This library can analyze runtime the structure of the heap, 
this is useful for debugging memory allocation.

## Operation

See example heapdemo2.ino 
