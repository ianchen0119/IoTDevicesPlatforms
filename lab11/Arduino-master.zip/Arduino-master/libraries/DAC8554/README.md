# DAC8554
Arduino library for DAC8554  Digital Analog Convertor

## Description

not tested extensively

## Operation

See examples

**demo_hw_spi.ino**
write a sawtooth to channel A followed by a sinus 
uses HW SPI

**demo_sw_spi.ino**
write a sawtooth to channel A followed by a sinus 
uses SW SPI

**demo_same_time_write.ino**
writes two square waves that trigger at the same time

**demo_sequential_write.ino**
writes two square waves sequentially (slight time difference)

**demo_powerdown.ino**
idem

## TODO

more testing
