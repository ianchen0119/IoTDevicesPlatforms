# Prandom

Arduino library for random number generation with Python random interface

# Description

See Python Random library - https://docs.python.org/3/library/random.html

# Operation

See examples

